import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const ProfileScreen = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Aqui vendría el Perfil del Usuario</Text>

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
  },
  text: {
    color: 'orange', // Cambia el color del texto aquí
    fontSize: 30, // Ajusta el tamaño del texto si es necesario
  },
});

export default ProfileScreen;
