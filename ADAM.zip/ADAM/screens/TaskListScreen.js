import React, { useContext } from 'react';
import { View, Text, FlatList, Button, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { TaskContext } from '../contexts/TaskContext';
//muestra la lista con las tareas anadidas
const TaskListScreen = () => {
  const { tasks } = useContext(TaskContext);
  const navigation = useNavigation();
//muestra cada una de las tareas existentes
  return (
    <View>
      <FlatList 
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View>
            <Text style={styles.input}>{item.title}</Text>
          </View>
        )}
      />
      <Button
        title="Agregar Tarea"
        onPress={() => navigation.navigate('Añadir Tareas')}
        color="orange" // Cambia el color del botón aquí

      />
    </View>
  );
};

const styles = StyleSheet.create({
  input: {
    paddingLeft: 10,
    fontSize: 20, // Cambia el tamaño del texto aquí
  },
});

export default TaskListScreen;
