import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { LineChart } from 'react-native-chart-kit';

const screenWidth = Dimensions.get('window').width;

const data = {
  labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio'],
  datasets: [
    {
      data: [20, 45, 28, 80, 99, 43],
      color: (opacity = 1) => `rgba(0, 200, 50, ${opacity})`, // Cambia el color de la línea aquí
      strokeWidth: 2, // Cambia el grosor de la línea aquí
    },
  ],
};

const chartConfig = {
  backgroundGradientFrom: '#fff',
  backgroundGradientTo: '#fff',
  color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`, // Cambia el color del texto aquí
  strokeWidth: 2, // Cambia el grosor de la línea aquí
  barPercentage: 0.5,
};

const ExtraScreen = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Grafica Semestral</Text>
      <LineChart
        data={data}
        width={screenWidth}
        height={220}
        chartConfig={chartConfig}
        bezier
        style={styles.chart}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
  },
  text: {
    color: 'orange',
    fontSize: 30,
  },
  chart: {
    marginVertical: 8,
    borderRadius: 16,
  },
});

export default ExtraScreen;
