import React, { useState, useContext } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';
import { TaskContext } from '../contexts/TaskContext';

// permite el anadir de tareas llamando al anadir tarea
const AddTaskScreen = ({ navigation }) => {
  const [task, setTask] = useState('');
  const { addTask } = useContext(TaskContext);
//anade la tarea y regresa a la pantalla principal
  const handleAddTask = () => {
    addTask(task);
    navigation.goBack();
  };
//muestra la pantalla con la tarea que se anade en nueva tarea
  return (
    <View style={styles.container}>
      <TextInput style={styles.input}
        placeholder="Escriba aquí la tarea a ingresar"
        value={task}
        onChangeText={setTask}
      />
      <Button 
        title="Agregar Tarea" 
        onPress={handleAddTask} 
        color="orange" // Cambia el color del botón aquí
        />
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  input: {
    height: 50, // Cambia la altura del TextInput aquí
    borderColor: 'black',
    borderWidth: 1,
    paddingLeft: 10,
    fontSize: 20, // Cambia el tamaño del texto aquí
    marginBottom: 20,
  },
});

export default AddTaskScreen;
