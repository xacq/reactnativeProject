//importacion de react
import React, { createContext, useState } from 'react';

const TaskContext = createContext();

//constante que posee la lista de tareas
  const TaskProvider = ({ children }) => {
    const [tasks, setTasks] = useState([  ]);

//constante que guarda la tarea a anadir
  const addTask = (title) => {
    const newTask = { id: Math.random().toString(), title };
    setTasks((prevTasks) => [...prevTasks, newTask]);
  };

// retorna la constante con las tareas ya creadas
  return (
    <TaskContext.Provider value={{ tasks, addTask }}>
      {children}
    </TaskContext.Provider>
  );
};

export { TaskContext, TaskProvider };
