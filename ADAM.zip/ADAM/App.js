import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import TaskListScreen from './screens/TaskListScreen';
import AddTaskScreen from './screens/AddTaskScreen';
import ProfileScreen from './screens/ProfileScreen'; // Nueva pantalla de perfil
import ExtraScreen from './screens/ExtraScreen'; // Nueva pantalla de perfil
import Icon from 'react-native-vector-icons/Ionicons'; // Para iconos
import { TaskProvider } from './contexts/TaskContext';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function TaskStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Lista de Tareas" component={TaskListScreen} />
      <Stack.Screen name="Añadir Tareas" component={AddTaskScreen} />
    </Stack.Navigator>
  );
}

function App() {
  return (
    <TaskProvider>
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            tabBarIcon: ({ focused, color, size }) => {
              let iconName;

              if (route.name === 'Tareas') {
                iconName = focused ? 'alarm' : 'alarm-outline';
              } else if (route.name === 'Gráfico') {
                iconName = focused ? 'bar-chart' : 'bar-chart-outline';
              } else if (route.name === 'Perfil') {
                iconName = focused ? 'accessibility' : 'accessibility-outline';
              }

              // Puedes retornar cualquier componente que desees aquí
              return <Icon name={iconName} size={size} color={color} />;
            },
            tabBarActiveTintColor: 'orange',
            tabBarInactiveTintColor: 'green',
          })}
        >
          <Tab.Screen name="Tareas" component={TaskStack} />
          <Tab.Screen name="Gráfico" component={ExtraScreen} />
          <Tab.Screen name="Perfil" component={ProfileScreen} />
        </Tab.Navigator>
      </NavigationContainer>
    </TaskProvider>

  );
}

export default App;
